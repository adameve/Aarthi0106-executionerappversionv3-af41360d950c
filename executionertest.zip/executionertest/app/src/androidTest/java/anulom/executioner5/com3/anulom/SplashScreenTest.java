//package anulom.executioner5.com3.anulom;
//
//
//import android.test.suitebuilder.annotation.LargeTest;
//import android.view.View;
//import android.view.ViewGroup;
//import android.view.ViewParent;
//
//@LargeTest
//@RunWith(AndroidJUnit4.class)
//public class SplashScreenTest {
//
//    @Rule
//    public ActivityTestRule<SplashScreen> mActivityTestRule = new ActivityTestRule<>(SplashScreen.class);
//
//    @Test
//    public void splashScreenTest() {
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(10000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction textInputEditText = onView(
//                allOf(withId(R.id.etmailid),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText.perform(click());
//
//        ViewInteraction textInputEditText2 = onView(
//                allOf(withId(R.id.etmailid),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText2.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(50);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction textInputEditText3 = onView(
//                allOf(withId(R.id.etmailid),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText3.perform(replaceText("shweta.test@anulom.comt"), closeSoftKeyboard());
//
//        ViewInteraction textInputEditText4 = onView(
//                allOf(withId(R.id.etpassword),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText4.perform(click());
//
//        ViewInteraction textInputEditText5 = onView(
//                allOf(withId(R.id.etmailid), withText("shweta.test@anulom.comt"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText5.perform(replaceText("shweta.test@anulom.com"));
//
//        ViewInteraction textInputEditText6 = onView(
//                allOf(withId(R.id.etmailid), withText("shweta.test@anulom.com"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText6.perform(closeSoftKeyboard());
//
//        ViewInteraction textInputEditText7 = onView(
//                allOf(withId(R.id.etpassword),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.design.widget.TextInputLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textInputEditText7.perform(replaceText("password123"), closeSoftKeyboard());
//
//        ViewInteraction appCompatCheckBox = onView(
//                allOf(withId(R.id.cbShowPwd), withText("SHOW PASSWORD"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        0),
//                                3)));
//        appCompatCheckBox.perform(scrollTo(), click());
//
//        ViewInteraction appCompatButton = onView(
//                allOf(withId(R.id.btnsubmit), withText("Submit"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        1),
//                                0)));
//        appCompatButton.perform(scrollTo(), click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3600000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatButton2 = onView(
//                allOf(withId(R.id.search_back), withText("Skip"), isDisplayed()));
//        appCompatButton2.perform(click());
//
//        ViewInteraction tabView = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        0),
//                        isDisplayed()));
//        tabView.perform(click());
//
//        ViewInteraction viewPager = onView(
//                allOf(withId(R.id.frag2_viewpager),
//                        childAtPosition(
//                                withParent(withId(R.id.viewpager)),
//                                1),
//                        isDisplayed()));
//        viewPager.perform(swipeRight());
//
//        ViewInteraction tabView2 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        0),
//                        isDisplayed()));
//        tabView2.perform(click());
//
//        ViewInteraction textView = onView(
//                allOf(withId(R.id.tvstatus1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textView.perform(click());
//
//        ViewInteraction button = onView(
//                allOf(withId(R.id.bSearch), withText("Check-in"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3546328);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction checkBox = onView(
//                allOf(withText("Door Step Visit Done"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                4)));
//        checkBox.perform(scrollTo(), click());
//
//        ViewInteraction spinner = onView(
//                childAtPosition(
//                        childAtPosition(
//                                withClassName(is("android.widget.ScrollView")),
//                                0),
//                        30));
//        spinner.perform(scrollTo(), click());
//
//        DataInteraction appCompatCheckedTextView = onData(anything())
//                .inAdapterView(childAtPosition(
//                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                        0))
//                .atPosition(1);
//        appCompatCheckedTextView.perform(click());
//
//        ViewInteraction button2 = onView(
//                allOf(withText("CONFIRM WITNESS AND UPDATE"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                41)));
//        button2.perform(scrollTo(), click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3526624);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction textView2 = onView(
//                allOf(withId(R.id.tvcomment1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        1),
//                                0),
//                        isDisplayed()));
//        textView2.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3513320);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction actionMenuItemView = onView(
//                allOf(withId(R.id.action_plus),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(R.id.toolbar),
//                                        2),
//                                0),
//                        isDisplayed()));
//        actionMenuItemView.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3504665);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatEditText = onView(
//                allOf(withId(R.id.etcomment),
//                        childAtPosition(
//                                allOf(withId(R.id.l2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.ScrollView")),
//                                                0)),
//                                2)));
//        appCompatEditText.perform(scrollTo(), click());
//
//        ViewInteraction appCompatEditText2 = onView(
//                allOf(withId(R.id.etcomment),
//                        childAtPosition(
//                                allOf(withId(R.id.l2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.ScrollView")),
//                                                0)),
//                                2)));
//        appCompatEditText2.perform(scrollTo(), replaceText("hiiiiio "), closeSoftKeyboard());
//
//        ViewInteraction appCompatSpinner = onView(
//                allOf(withId(R.id.spinner),
//                        childAtPosition(
//                                allOf(withId(R.id.l2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.ScrollView")),
//                                                0)),
//                                5)));
//        appCompatSpinner.perform(scrollTo(), click());
//
//        DataInteraction appCompatTextView = onData(anything())
//                .inAdapterView(childAtPosition(
//                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                        0))
//                .atPosition(1);
//        appCompatTextView.perform(click());
//
//        ViewInteraction appCompatButton3 = onView(
//                allOf(withId(R.id.btn_date),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(R.id.l2),
//                                        16),
//                                1)));
//        appCompatButton3.perform(scrollTo(), click());
//
//        ViewInteraction appCompatButton4 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton4.perform(scrollTo(), click());
//
//        ViewInteraction appCompatSpinner2 = onView(
//                allOf(withId(R.id.spinner_remimnder),
//                        childAtPosition(
//                                allOf(withId(R.id.l2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.ScrollView")),
//                                                0)),
//                                17)));
//        appCompatSpinner2.perform(scrollTo(), click());
//
//        DataInteraction appCompatTextView2 = onData(anything())
//                .inAdapterView(childAtPosition(
//                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                        0))
//                .atPosition(3);
//        appCompatTextView2.perform(click());
//
//        ViewInteraction appCompatButton5 = onView(
//                allOf(withId(R.id.btnsubmit), withText("Submit"),
//                        childAtPosition(
//                                allOf(withId(R.id.l2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.ScrollView")),
//                                                0)),
//                                18)));
//        appCompatButton5.perform(scrollTo(), click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3461383);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        pressBack();
//
//        pressBack();
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3457032);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction textView3 = onView(
//                allOf(withId(R.id.tvAddpay1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        2),
//                                0),
//                        isDisplayed()));
//        textView3.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3447462);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatEditText3 = onView(
//                allOf(withId(R.id.tvpay3),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.TableLayout")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        appCompatEditText3.perform(replaceText("81"), closeSoftKeyboard());
//
//        ViewInteraction appCompatRadioButton = onView(
//                allOf(withId(R.id.rp), withText("Remaining Payment"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup5),
//                                        childAtPosition(
//                                                withId(R.id.relativeLayout),
//                                                1)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton.perform(click());
//
//        pressBack();
//
//        ViewInteraction appCompatEditText4 = onView(
//                allOf(withId(R.id.editText1),
//                        childAtPosition(
//                                allOf(withId(R.id.relativeLayout),
//                                        childAtPosition(
//                                                withId(R.id.l1),
//                                                5)),
//                                0),
//                        isDisplayed()));
//        appCompatEditText4.perform(replaceText("htest"), closeSoftKeyboard());
//
//        pressBack();
//
//        ViewInteraction appCompatButton6 = onView(
//                allOf(withId(R.id.btnupdate2), withText("CONFIRM AMOUNT AND UPDATE"),
//                        childAtPosition(
//                                allOf(withId(R.id.l1),
//                                        childAtPosition(
//                                                withId(R.id.card_view),
//                                                2)),
//                                6),
//                        isDisplayed()));
//        appCompatButton6.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3378818);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction switch_ = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_.perform(click());
//
//        ViewInteraction switch_2 = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_2.perform(click());
//
//        ViewInteraction button3 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button3.perform(click());
//
//        ViewInteraction appCompatButton7 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton7.perform(scrollTo(), click());
//
//        ViewInteraction button4 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button4.perform(click());
//
//        ViewInteraction appCompatButton8 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton8.perform(scrollTo(), click());
//
//        ViewInteraction button5 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button5.perform(click());
//
//        ViewInteraction appCompatRadioButton2 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton2.perform(click());
//
//        ViewInteraction appCompatRadioButton3 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton3.perform(click());
//
//        ViewInteraction appCompatRadioButton4 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton4.perform(click());
//
//        ViewInteraction appCompatButton9 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton9.perform(scrollTo(), click());
//
//        ViewInteraction radioButton = onView(
//                allOf(withId(R.id.button), withText("1/2 hour"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                4)),
//                                0),
//                        isDisplayed()));
//        radioButton.perform(click());
//
//        ViewInteraction radioButton2 = onView(
//                allOf(withId(R.id.buttonr2), withText("2"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup3),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                6)),
//                                1),
//                        isDisplayed()));
//        radioButton2.perform(click());
//
//        ViewInteraction button6 = onView(
//                allOf(withId(R.id.text8), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                8),
//                        isDisplayed()));
//        button6.perform(click());
//
//        ViewInteraction button7 = onView(
//                allOf(withId(R.id.text7), withText("CANCEL"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                7),
//                        isDisplayed()));
//        button7.perform(click());
//
//        ViewInteraction tabView3 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView3.perform(click());
//
//        ViewInteraction viewPager2 = onView(
//                allOf(withId(R.id.frag2_viewpager),
//                        childAtPosition(
//                                withParent(withId(R.id.viewpager)),
//                                1),
//                        isDisplayed()));
//        viewPager2.perform(swipeLeft());
//
//        ViewInteraction switch_3 = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_3.perform(click());
//
//        ViewInteraction button8 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button8.perform(click());
//
//        ViewInteraction appCompatRadioButton5 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton5.perform(click());
//
//        ViewInteraction appCompatButton10 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton10.perform(scrollTo(), click());
//
//        ViewInteraction radioButton3 = onView(
//                allOf(withId(R.id.button), withText("1/2 hour"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                4)),
//                                0),
//                        isDisplayed()));
//        radioButton3.perform(click());
//
//        ViewInteraction radioButton4 = onView(
//                allOf(withId(R.id.buttonr1), withText("1"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup3),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                6)),
//                                0),
//                        isDisplayed()));
//        radioButton4.perform(click());
//
//        ViewInteraction button9 = onView(
//                allOf(withId(R.id.text8), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                8),
//                        isDisplayed()));
//        button9.perform(click());
//
//        ViewInteraction textView4 = onView(
//                allOf(withId(R.id.tvstatus1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textView4.perform(click());
//
//        ViewInteraction textView5 = onView(
//                allOf(withId(R.id.tvstatus1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        textView5.perform(click());
//
//        ViewInteraction button10 = onView(
//                allOf(withId(R.id.bSearch), withText("Check-in"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button10.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3262782);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatImageButton = onView(
//                allOf(withContentDescription("Navigate up"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.LinearLayout")),
//                                        0),
//                                1)));
//        appCompatImageButton.perform(scrollTo(), click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3257817);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction tabView4 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        0),
//                        isDisplayed()));
//        tabView4.perform(click());
//
//        ViewInteraction viewPager3 = onView(
//                allOf(withId(R.id.frag2_viewpager),
//                        childAtPosition(
//                                withParent(withId(R.id.viewpager)),
//                                1),
//                        isDisplayed()));
//        viewPager3.perform(swipeRight());
//
//        ViewInteraction switch_4 = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_4.perform(click());
//
//        ViewInteraction switch_5 = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_5.perform(click());
//
//        ViewInteraction button11 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button11.perform(click());
//
//        ViewInteraction appCompatRadioButton6 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("PM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                1),
//                        isDisplayed()));
//        appCompatRadioButton6.perform(click());
//
//        ViewInteraction appCompatRadioButton7 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton7.perform(click());
//
//        ViewInteraction appCompatButton11 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton11.perform(scrollTo(), click());
//
//        ViewInteraction radioButton5 = onView(
//                allOf(withId(R.id.button), withText("1/2 hour"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                4)),
//                                0),
//                        isDisplayed()));
//        radioButton5.perform(click());
//
//        ViewInteraction radioButton6 = onView(
//                allOf(withId(R.id.button), withText("1/2 hour"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                4)),
//                                0),
//                        isDisplayed()));
//        radioButton6.perform(click());
//
//        ViewInteraction radioButton7 = onView(
//                allOf(withId(R.id.buttonr1), withText("1"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup3),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                6)),
//                                0),
//                        isDisplayed()));
//        radioButton7.perform(click());
//
//        ViewInteraction radioButton8 = onView(
//                allOf(withId(R.id.buttonr1), withText("1"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup3),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                6)),
//                                0),
//                        isDisplayed()));
//        radioButton8.perform(click());
//
//        ViewInteraction button12 = onView(
//                allOf(withId(R.id.text8), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                8),
//                        isDisplayed()));
//        button12.perform(click());
//
//        ViewInteraction button13 = onView(
//                allOf(withId(R.id.text7), withText("CANCEL"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                7),
//                        isDisplayed()));
//        button13.perform(click());
//
//        ViewInteraction switch_6 = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_6.perform(click());
//
//        ViewInteraction button14 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button14.perform(click());
//
//        ViewInteraction button15 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button15.perform(click());
//
//        ViewInteraction appCompatButton12 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton12.perform(scrollTo(), click());
//
//        ViewInteraction appCompatRadioButton8 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("PM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                1),
//                        isDisplayed()));
//        appCompatRadioButton8.perform(click());
//
//        ViewInteraction appCompatRadioButton9 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton9.perform(click());
//
//        ViewInteraction appCompatRadioButton10 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton10.perform(click());
//
//        ViewInteraction appCompatRadioButton11 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton11.perform(click());
//
//        ViewInteraction appCompatRadioButton12 = onView(
//                allOf(withClassName(is("android.support.v7.widget.AppCompatRadioButton")), withText("AM"),
//                        childAtPosition(
//                                allOf(withClassName(is("android.widget.RadioGroup")),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                3)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton12.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3600000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatButton13 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton13.perform(scrollTo(), click());
//
//        ViewInteraction radioButton9 = onView(
//                allOf(withId(R.id.button), withText("1/2 hour"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup2),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                4)),
//                                0),
//                        isDisplayed()));
//        radioButton9.perform(click());
//
//        ViewInteraction radioButton10 = onView(
//                allOf(withId(R.id.buttonr1), withText("1"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup3),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                6)),
//                                0),
//                        isDisplayed()));
//        radioButton10.perform(click());
//
//        ViewInteraction button16 = onView(
//                allOf(withId(R.id.text8), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                8),
//                        isDisplayed()));
//        button16.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3554638);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        pressBack();
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3600000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction tabView5 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.tabsfragment),
//                                0),
//                        0),
//                        isDisplayed()));
//        tabView5.perform(click());
//
//        ViewInteraction appCompatButton14 = onView(
//                allOf(withId(R.id.search_back), withText("Skip"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.TableLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        appCompatButton14.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3593810);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction switch_7 = onView(
//                allOf(withId(R.id.switch1),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                4),
//                        isDisplayed()));
//        switch_7.perform(click());
//
//        ViewInteraction button17 = onView(
//                allOf(withId(R.id.owner2),
//                        childAtPosition(
//                                allOf(withId(R.id.relative),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.LinearLayout")),
//                                                0)),
//                                1),
//                        isDisplayed()));
//        button17.perform(click());
//
//        ViewInteraction button18 = onView(
//                allOf(withId(R.id.buttontime1),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        button18.perform(click());
//
//        ViewInteraction appCompatButton15 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton15.perform(scrollTo(), click());
//
//        ViewInteraction button19 = onView(
//                allOf(withId(R.id.text8), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                4),
//                        isDisplayed()));
//        button19.perform(click());
//
//        ViewInteraction textView6 = onView(
//                allOf(withId(R.id.tvdate2), withText("RESCHEDULE"),
//                        childAtPosition(
//                                withParent(withId(R.id.tasklist)),
//                                1),
//                        isDisplayed()));
//        textView6.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3561368);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatRadioButton13 = onView(
//                allOf(withId(R.id.cust), withText("Request by Customer"),
//                        childAtPosition(
//                                allOf(withId(R.id.radioGroup),
//                                        childAtPosition(
//                                                withClassName(is("android.widget.RelativeLayout")),
//                                                2)),
//                                0),
//                        isDisplayed()));
//        appCompatRadioButton13.perform(click());
//
//        ViewInteraction appCompatButton16 = onView(
//                allOf(withId(R.id.btn_date),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(android.R.id.content),
//                                        0),
//                                4),
//                        isDisplayed()));
//        appCompatButton16.perform(click());
//
//        ViewInteraction appCompatButton17 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton17.perform(scrollTo(), click());
//
//        ViewInteraction appCompatButton18 = onView(
//                allOf(withId(R.id.btn_time),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(android.R.id.content),
//                                        0),
//                                6),
//                        isDisplayed()));
//        appCompatButton18.perform(click());
//
//        ViewInteraction appCompatButton19 = onView(
//                allOf(withId(android.R.id.button1), withText("OK"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.ScrollView")),
//                                        0),
//                                3)));
//        appCompatButton19.perform(scrollTo(), click());
//
//        ViewInteraction appCompatButton20 = onView(
//                allOf(withId(R.id.btnupdate2), withText("RESCHEDULE"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(android.R.id.content),
//                                        0),
//                                7),
//                        isDisplayed()));
//        appCompatButton20.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3542178);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction actionMenuItemView2 = onView(
//                allOf(withId(R.id.action_refresh),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(R.id.toolbar),
//                                        1),
//                                1),
//                        isDisplayed()));
//        actionMenuItemView2.perform(click());
//
//        ViewInteraction appCompatCheckBox2 = onView(
//                allOf(withId(R.id.checkBox2), withText("Biometric"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                1),
//                        isDisplayed()));
//        appCompatCheckBox2.perform(click());
//
//        ViewInteraction appCompatButton21 = onView(
//                allOf(withId(R.id.button7), withText("Refresh"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.PopupWindow$PopupBackgroundView")),
//                                        0),
//                                6),
//                        isDisplayed()));
//        appCompatButton21.perform(click());
//
//        ViewInteraction appCompatButton22 = onView(
//                allOf(withId(R.id.search_back), withText("Skip"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.TableLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        appCompatButton22.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3496992);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        openActionBarOverflowOrOptionsMenu(getInstrumentation().getTargetContext());
//
//        ViewInteraction appCompatTextView3 = onView(
//                allOf(withId(R.id.title), withText("Cancelled Appointments"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.v7.view.menu.ListMenuItemView")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        appCompatTextView3.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3487038);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction tabView6 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs1),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView6.perform(click());
//
//        ViewInteraction viewPager4 = onView(
//                allOf(withId(R.id.frag2_viewpager1),
//                        childAtPosition(
//                                withParent(withId(R.id.viewpager5)),
//                                1),
//                        isDisplayed()));
//        viewPager4.perform(swipeLeft());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        pressBack();
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3479590);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        pressBack();
//
//        openActionBarOverflowOrOptionsMenu(getInstrumentation().getTargetContext());
//
//        ViewInteraction appCompatTextView4 = onView(
//                allOf(withId(R.id.title), withText("Pending Works"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.support.v7.view.menu.ListMenuItemView")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        appCompatTextView4.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3472332);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatButton23 = onView(
//                allOf(withId(R.id.search_back), withText("Skip"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.TableLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        appCompatButton23.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3467151);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction tabView7 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView7.perform(click());
//
//        ViewInteraction viewPager5 = onView(
//                allOf(withId(R.id.frag2_viewpager),
//                        childAtPosition(
//                                withParent(withId(R.id.viewpager)),
//                                1),
//                        isDisplayed()));
//        viewPager5.perform(swipeLeft());
//
//        ViewInteraction tabView8 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView8.perform(click());
//
//        ViewInteraction tabView9 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView9.perform(click());
//
//        ViewInteraction viewPager6 = onView(
//                allOf(withId(R.id.frag2_viewpager),
//                        childAtPosition(
//                                withParent(withId(R.id.viewpager)),
//                                1),
//                        isDisplayed()));
//        viewPager6.perform(swipeRight());
//
//        ViewInteraction tabView10 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView10.perform(click());
//
//        ViewInteraction actionMenuItemView3 = onView(
//                allOf(withId(R.id.search), withContentDescription("Search"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withId(R.id.toolbar),
//                                        1),
//                                0),
//                        isDisplayed()));
//        actionMenuItemView3.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3433257);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction appCompatButton24 = onView(
//                allOf(withId(R.id.search_back), withText("back"),
//                        childAtPosition(
//                                childAtPosition(
//                                        withClassName(is("android.widget.TableLayout")),
//                                        0),
//                                0),
//                        isDisplayed()));
//        appCompatButton24.perform(click());
//
//        // Added a sleep statement to match the app's execution delay.
//        // The recommended way to handle such scenarios is to use Espresso idling resources:
//        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
//        try {
//            Thread.sleep(3427774);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        ViewInteraction tabView11 = onView(
//                allOf(childAtPosition(
//                        childAtPosition(
//                                withId(R.id.frag2_tabs),
//                                0),
//                        1),
//                        isDisplayed()));
//        tabView11.perform(click());
//
//    }
//
//    private static Matcher<View> childAtPosition(
//            final Matcher<View> parentMatcher, final int position) {
//
//        return new TypeSafeMatcher<View>() {
//            @Override
//            public void describeTo(Description description) {
//                description.appendText("Child at position " + position + " in parent ");
//                parentMatcher.describeTo(description);
//            }
//
//            @Override
//            public boolean matchesSafely(View view) {
//                ViewParent parent = view.getParent();
//                return parent instanceof ViewGroup && parentMatcher.matches(parent)
//                        && view.equals(((ViewGroup) parent).getChildAt(position));
//            }
//        };
//    }
//}
