package anulom.executioner5.com3.anulom;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;



public class nopayment extends AppCompatActivity {
    TextView t1;
    String value;

    public void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.nopayment);



    }
}